#encoding=utf-8
import socket;
import time
rhost = ('192.168.0.100', 3003)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
	sock.connect(rhost)
except:
	print '连不上服务器'
time.sleep(2)
sock.send('^1900007$')
while True:
	try:
		revstring = sock.recv(1024)
		print revstring
	except:
		print '断开了连接'
		break
